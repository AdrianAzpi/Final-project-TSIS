/*
 Juego de Gato
 Temas Selectos de Ingenieria en Software
 Guerrero Azpitarte Adrian Eduardo
 
 Version 1.0
 */
import UIKit

//ar myPlayer = selectPlayer()

var Tablero = [["-","-","-"],["-","-","-"],["-","-","-"]]


enum Fichas: String {
    case X = "X"
    case O = "O"
    case i = ""
}


struct Player {
    var name: String
}

var myfirstplayer = Player(name: "Adrian")
var mySecondtplayer = Player(name: "Eduardo")
var empyBoard = "__|__|__\n__|__|__ \n  |  |  "


//Funcion que simula lanzar una moneda para ver que jugador empieza
func selectPlayer()-> Bool {
    let number = Bool.random()
    // print("Dame el nombre del jugador 1? ")

    let player1 = true
    let player2 = false
    if number == true {
        print("Empieza el jugador 1 con X")
        return player1
    } else {
        print("Empieza el jugador 2 con O")
        return player2
    }
}


func checkIfYouWin() -> Bool{
    //Posibilidad 1  OOO
    if ((Tablero[0][0] == "O") && (Tablero[0][1] == "O") && (Tablero[0][2] == "O")) {
        print("YOU WIN")
         return true
    //Posibilidad 2
    //              OOO
    }else if ((Tablero[1][0] == "O") && (Tablero[1][1] == "O") && (Tablero[1][2] == "O")) {
        print("YOU WIN")

        return true
    //Posibilidad 3
    //
    //              OOO
    }else if ((Tablero[2][0] == "O") && (Tablero[2][1] == "O") && (Tablero[2][2] == "O")) {
        print("YOU WIN")

        return true
    //Posibilidad 4 O
    //              O
    //              O
    } else if ((Tablero[0][0] == "O") && (Tablero[1][0] == "O") && (Tablero[2][0] == "O")) {
        print("YOU WIN")
        return true
    //Posibilidad 5 .  O
    //                 O
    //                 O
    }else if ((Tablero[0][1] == "O") && (Tablero[1][1] == "O") && (Tablero[2][1] == "O")) {
        print("YOU WIN")
        return true
    //Posibilidad 6  . . O
    //                   O
    //                   O
    }else if ((Tablero[0][2] == "O") && (Tablero[1][2] == "O") && (Tablero[2][2] == "O")) {
        print("YOU WIN")
        return true
    //Posibilidad 7   O
    //                  O
    //                    O
    }else if ((Tablero[0][0] == "O") && (Tablero[1][1] == "O") && (Tablero[2][2] == "O")) {
        print("YOU WIN")
        return true
    //Posibilidad 8      O
    //                 O
    //               O
    }else if ((Tablero[0][2] == "O") && (Tablero[1][1] == "O") && (Tablero[2][0] == "O")) {
        print("YOU WIN")
        return true
        
        
    
        
        //Posibilidad 9  XXX
    }else if ((Tablero[0][0] == "X") && (Tablero[0][1] == "X") && (Tablero[0][2] == "X")) {
        print("YOU WIN")
        return true
        //Posibilidad 10
        //              XXX
    }else if ((Tablero[1][0] == "X") && (Tablero[1][1] == "X") && (Tablero[1][2] == "X")) {
        print("YOU WIN")
        return true
        //Posibilidad 11
        //
        //              XXX
    }else if ((Tablero[2][0] == "X") && (Tablero[2][1] == "X") && (Tablero[2][2] == "X")) {
        print("YOU WIN")
        return true
        //Posibilidad 12 X
        //               X
        //               X
    } else if ((Tablero[0][0] == "X") && (Tablero[1][0] == "X") && (Tablero[2][0] == "X")) {
        print("YOU WIN")
        return true
        //Posibilidad 13   X
        //                 X
        //
    }else if ((Tablero[0][1] == "X") && (Tablero[1][1] == "X") && (Tablero[2][1] == "X")) {
        print("YOU WIN")
        return true
        //Posibilidad 14     X
        //                   X
        //                   X
    }else if ((Tablero[0][2] == "X") && (Tablero[1][2] == "X") && (Tablero[2][2] == "X")) {
        print("YOU WIN")
        return true
        //Posibilidad 15   X
        //                  X
        //                    X
    }else if ((Tablero[0][0] == "X") && (Tablero[1][1] == "X") && (Tablero[2][2] == "X")) {
        print("YOU WIN")
        return true
        //Posibilidad 16     X
        //                 X
        //               X
    }else if ((Tablero[0][2] == "X") && (Tablero[1][1] == "X") && (Tablero[2][0] == "X")) {
        print("YOU WIN")
        return true
    }
    
    
    return false
}

func printBoard(){
    
    print(index)
    print(Tablero[0][0], Tablero[0][1], Tablero[0][2])
    ("\n")
    print(Tablero[1][0], Tablero[1][1], Tablero[1][2])
    ("\n")
    print(Tablero[2][0], Tablero[2][1], Tablero[2][2])
    print("-------------------------------------\n")
    
}

//Aqui es donde comienza la magia D:--------------------------------
//Se puede ganar a partir del 5º movimiento --------------------------------


func fillBoard(movement: String, positionX: Int, positionY: Int) {
    
    let myPositionX = positionX
    let myPositionY = positionY
    
    if (movement == "O" || movement == "o") {
        switch myPositionX {
        case 0:
            if myPositionY == 0 {
                //Primero checar que no exista ya algo ahi en cada movimiento
                if Tablero[0][0] == "-" {
                    Tablero[0][0] = "O"
                    printBoard()
                    checkIfYouWin()
                }else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[0][0])\".")
                }
            }else if myPositionY == 1 {
                if Tablero[0][1] == "-"{
                    Tablero[0][1] = "O"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[0][1])\".")
                }
            }else if myPositionY == 2 {
                if Tablero[0][2] == "-"{
                    Tablero[0][2] = "O"
                    printBoard()
                    checkIfYouWin()
                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[0][2])\".")
                }
            }else {
                print("Te pasaste en el indice en Y, recuerda que solo val del 0 al 2")
            }
        case 1:
            if myPositionY == 0 {
                if Tablero[1][0] == "-"{
                    Tablero[1][0] = "O"
                    printBoard()
                    checkIfYouWin()
                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[1][0])\".")
                }
            }else if myPositionY == 1 {
                if Tablero[1][1] == "-"{
                    Tablero[1][1] = "O"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[1][1])\".")
                }
            }else if myPositionY == 2 {
                if Tablero[1][2] == "-"{
                    Tablero[1][2] = "O"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[1][2])\".")
                }
            }else {
                print("Te pasaste en el indice en Y, recuerda que solo val del 0 al 2")
            }
        case 2:
            if myPositionY == 0 {
                //Primero checar que no exista ya algo ahi en cada movimiento
                if Tablero[2][0] == "-"{
                    Tablero[2][0] = "O"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[2][0])\".")
                }
            }else if myPositionY == 1 {
                if Tablero[2][1] == "-"{
                    Tablero[2][1] = "O"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[2][1])\".")
                }
            }else if myPositionY == 2 {
                if Tablero[2][2] == "-"{
                    Tablero[2][2] = "O"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[2][2])\".")
                }
            }else {
                print("Te pasaste en el indice en Y, recuerda que solo val del 0 al 2")
            }
        default:
            print("Te pasaste del indice en X, recuerda que solo va del 0 al 2")
        }
        //return "Se agrego un O en X = \(myPositionX) y en Y = \(myPositionY)"
        
    } else if (movement == "X" || movement == "x") {
        switch myPositionX {
        case 0:
            if myPositionY == 0 {
                if Tablero[0][0] == "-"{
                    Tablero[0][0] = "X"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[0][0])\".")
                }
            }else if myPositionY == 1 {
                if Tablero[0][1] == "-"{
                    Tablero[0][1] = "X"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[0][1])\".")
                }
            }else if myPositionY == 2 {
                if Tablero[0][2] == "-"{
                    Tablero[0][2] = "X"
                    printBoard()
                    checkIfYouWin()

                } else {
                    print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[0][2])\".")
                }
            }else {
                print("Te pasaste en el indice en Y, recuerda que solo val del 0 al 2")
            }
            case 1:
                if myPositionY == 0 {
                    if Tablero[1][0] == "-"{
                        Tablero[1][0] = "X"
                        printBoard()
                        checkIfYouWin()

                    } else {
                        print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[1][0])\".")
                    }
                }else if myPositionY == 1 {
                    if Tablero[1][1] == "-"{
                        Tablero[1][1] = "X"
                        printBoard()
                        checkIfYouWin()

                    } else {
                        print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[1][1])\".")
                    }
                }else if myPositionY == 2 {
                    if Tablero[1][2] == "-"{
                        Tablero[1][2] = "X"
                        printBoard()
                        checkIfYouWin()

                    } else {
                        print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[1][2])\".")
                    }
                }else {
                    print("Te pasaste en el indice en Y, recuerda que solo val del 0 al 2")
                }
            case 2:
                if myPositionY == 0 {
                    if Tablero[2][0] == "-"{
                        Tablero[2][0] = "X"
                        printBoard()
                        checkIfYouWin()

                    } else {
                        print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[2][0])\".")
                    }
                }else if myPositionY == 1 {
                    if Tablero[2][1] == "-"{
                        Tablero[2][1] = "X"
                        printBoard()
                        checkIfYouWin()

                    } else {
                        print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[2][1])\".")
                    }
                }else if myPositionY == 2 {
                    if Tablero[2][2] == "-"{
                        Tablero[2][2] = "X"
                        printBoard()
                        checkIfYouWin()

                    } else {
                        print("No puedes poner un tu ficha en ese lugar, ya existe la pieza \"\(Tablero[2][2])\".")
                    }
                }else {
                    print("Te pasaste en el indice en Y, recuerda que solo val del 0 al 2")
                }
            default:
                print("Te pasaste del indice en X, recuerda que solo va del 0 al 2")
            }
        //return "Se agrego un X en X = \(myPositionX) y en Y = \(myPositionY)"
        
    }else {
        print("Solo puedes agregar movimientos con las letras 'X' o 'O' M/m")
    }
    
}

//Termina funcion -----------------------------------------------------------------------


printBoard()
//var firstmovement = fillBoard(movement: "o", positionX: 0, positionY: 0)
////var firstmovement3 = fillBoard(movement: "x", positionX: 0, positionY: 1)
//var secondMovement = fillBoard(movement: "X", positionX: 0, positionY: 1)
//var thirdMovement = fillBoard(movement: "O", positionX: 0, positionY: 2)
//var fourthMovement = fillBoard(movement: "X", positionX: 1, positionY: 0)
//var fifthMovement = fillBoard(movement: "O", positionX: 1, positionY: 1)
//var sixthMovement = fillBoard(movement: "X", positionX: 1, positionY: 2)
//// sixthMovement2 = fillBoard(movement: "O", positionX: 1, positionY: 2)
//var seventhMovement = fillBoard(movement: "O", positionX: 2, positionY: 0)
//var eighthMovement = fillBoard(movement: "X", positionX: 2, positionY: 1)
//var ninthMovement = fillBoard(movement: "O", positionX: 2, positionY: 2)
//

var firstmovement = fillBoard(movement: "o", positionX: 0, positionY: 0)
var secondMovement = fillBoard(movement: "o", positionX: 1, positionY: 1)
var thirdMovement = fillBoard(movement: "O", positionX: 2, positionY: 2)
//var sixthMovement = fillBoard(movement: "X", positionX: 1, positionY: 0)
//var sixthMovement2 = fillBoard(movement: "X", positionX: 0, positionY: 2)
